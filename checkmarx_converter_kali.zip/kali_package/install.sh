#!/usr/bin/env bash
# =============================================================================
#  install.sh  —  Checkmarx → NetSentries Report Converter
#  Offline installer for Kali Linux (no internet required)
# =============================================================================

set -e  # exit immediately on any error

CYAN="\033[0;36m"
GREEN="\033[0;32m"
YELLOW="\033[1;33m"
RED="\033[0;31m"
RESET="\033[0m"
BOLD="\033[1m"

banner() {
    echo ""
    echo -e "${CYAN}${BOLD}╔══════════════════════════════════════════════════════╗${RESET}"
    echo -e "${CYAN}${BOLD}║     Checkmarx → NetSentries  |  Offline Installer    ║${RESET}"
    echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════╝${RESET}"
    echo ""
}

info()    { echo -e "${CYAN}[→]${RESET} $1"; }
success() { echo -e "${GREEN}[✓]${RESET} $1"; }
warn()    { echo -e "${YELLOW}[!]${RESET} $1"; }
error()   { echo -e "${RED}[✗]${RESET} $1"; exit 1; }

# ── Resolve script directory (works even if called from elsewhere) ────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WHEELS_DIR="$SCRIPT_DIR/wheels"

banner

# ── 1. Check Python ───────────────────────────────────────────────────────────
info "Checking Python installation..."
if command -v python3 &>/dev/null; then
    PY=$(command -v python3)
    PY_VER=$("$PY" --version 2>&1)
    success "Found: $PY_VER  ($PY)"
elif command -v python &>/dev/null; then
    PY=$(command -v python)
    PY_VER=$("$PY" --version 2>&1)
    # Ensure it's Python 3
    if "$PY" -c "import sys; sys.exit(0 if sys.version_info.major==3 else 1)"; then
        success "Found: $PY_VER  ($PY)"
    else
        error "Python 3 is required. Found Python 2. Install python3 first."
    fi
else
    error "Python 3 is not installed. Run:  sudo apt-get install python3 python3-pip"
fi

# ── 2. Check pip ──────────────────────────────────────────────────────────────
info "Checking pip..."
if "$PY" -m pip --version &>/dev/null; then
    PIP_VER=$("$PY" -m pip --version 2>&1 | head -1)
    success "pip found: $PIP_VER"
else
    warn "pip not found. Attempting to install via ensurepip..."
    "$PY" -m ensurepip --upgrade 2>/dev/null || \
        error "pip could not be installed. Run:  sudo apt-get install python3-pip"
fi

# ── 3. Check wheel files exist ────────────────────────────────────────────────
info "Checking offline wheel files..."
MISSING=0
for WHL in et_xmlfile-2.0.0-py3-none-any.whl openpyxl-3.1.5-py2.py3-none-any.whl; do
    if [ ! -f "$WHEELS_DIR/$WHL" ]; then
        warn "Missing: wheels/$WHL"
        MISSING=1
    else
        success "Found: wheels/$WHL"
    fi
done
[ "$MISSING" -eq 1 ] && error "One or more wheel files are missing from the 'wheels/' directory."

# ── 4. Install wheels ─────────────────────────────────────────────────────────
echo ""
info "Installing et-xmlfile (openpyxl dependency)..."
"$PY" -m pip install \
    "$WHEELS_DIR/et_xmlfile-2.0.0-py3-none-any.whl" \
    --no-index \
    --quiet && success "et-xmlfile installed."

info "Installing openpyxl..."
"$PY" -m pip install \
    "$WHEELS_DIR/openpyxl-3.1.5-py2.py3-none-any.whl" \
    --no-index \
    --quiet && success "openpyxl installed."

# ── 5. Verify import ──────────────────────────────────────────────────────────
echo ""
info "Verifying installation..."
"$PY" -c "
import openpyxl
print(f'  openpyxl  version : {openpyxl.__version__}')
import et_xmlfile
print(f'  et-xmlfile version: {et_xmlfile.__version__}')
" && success "All packages imported successfully."

# ── 6. Check script files ─────────────────────────────────────────────────────
echo ""
info "Checking required files..."
SCRIPT="$SCRIPT_DIR/checkmarx_to_example.py"
TEMPLATE="$SCRIPT_DIR/example file.xlsx"

[ -f "$SCRIPT" ]   && success "Script found  : checkmarx_to_example.py" \
                   || warn    "Script missing: checkmarx_to_example.py  (copy it into this folder)"

[ -f "$TEMPLATE" ] && success "Template found: 'example file.xlsx'" \
                   || warn    "Template missing: 'example file.xlsx'  (copy it into this folder)"

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════════════╗${RESET}"
echo -e "${GREEN}${BOLD}║            Installation complete!                    ║${RESET}"
echo -e "${GREEN}${BOLD}╚══════════════════════════════════════════════════════╝${RESET}"
echo ""
echo -e "${BOLD}Usage:${RESET}"
echo -e "  ${CYAN}# Simple (all files in same folder):${RESET}"
echo -e "  python3 checkmarx_to_example.py"
echo ""
echo -e "  ${CYAN}# With explicit paths:${RESET}"
echo -e "  python3 checkmarx_to_example.py \\"
echo -e "    --input  checkmarx.xlsx \\"
echo -e "    --template \"example file.xlsx\" \\"
echo -e "    --output  output_report.xlsx"
echo ""
