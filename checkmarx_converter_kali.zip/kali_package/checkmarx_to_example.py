"""
checkmarx_to_example.py
-----------------------
Converts a Checkmarx SAST report (checkmarx.xlsx) into the
NetSentries "example file.xlsx" report format.

Dependencies (local / no internet required):
    pip install openpyxl      (already ships with most Python distros,
                               or install from a local wheel)

Usage:
    python checkmarx_to_example.py
        --input  checkmarx.xlsx
        --template "example file.xlsx"
        --output  output_report.xlsx

All three arguments have default values matching the files in the
same directory, so a plain `python checkmarx_to_example.py` works too.
"""

import argparse
import copy
import os
import sys
from datetime import datetime

try:
    import openpyxl
    from openpyxl.styles import (
        PatternFill, Font, Alignment, Border, Side, GradientFill
    )
    from openpyxl.utils import get_column_letter
except ImportError:
    sys.exit(
        "[ERROR] openpyxl is not installed.\n"
        "Install it offline with:  pip install openpyxl\n"
        "(or copy the openpyxl wheel to this machine and install it)"
    )

# ---------------------------------------------------------------------------
# Column mapping:  Checkmarx column  →  Example "Vulnerability Details" column
# ---------------------------------------------------------------------------
# The example sheet headers start at row 3, data from row 4.
# We'll derive as much as possible from the Checkmarx data.
# Columns in the example sheet (1-indexed):
#   1  Sr. No
#   2  Vulnerability Title        ← Query (col 1)
#   3  Risk Level                 ← Result Severity (col 35)
#   4  Status                     ← Result Status  (col 39)
#   5  CVSS Score v 4.0           ← (not in Checkmarx – left empty)
#   6  DREAD Risk Score           ← (not in Checkmarx – left empty)
#   7  OWASP/ WASC/ CWE Category  ← best available OWASP column (16, 6, 3, 8)
#   8  Abstract                   ← QueryPath (col 2)  — best description available
#   9  POC                        ← SrcFileName:Line → DestFileName:DestLine (cols 24-33)
#  10  Replication Effort         ← (left empty)
#  11  Impact                     ← (left empty)
#  12  Vulnerable URLs/ IPs       ← Link (col 38)
#  13  Affected Assets            ← SrcFileName (col 24)
#  14  Remediation recommendation ← (left empty)
#  15  Remediation Effort         ← (left empty)
#  16  References                 ← Link (col 38)
#  17  Client Justification       ← (left empty)
#  18  NetSentries Comments       ← Comment (col 37)
#  19  Remarks                    ← Result State (col 34)

# Checkmarx column indices (1-based, used when reading .xlsx):
CX = {
    "Query":           1,
    "QueryPath":       2,
    "OWASP_2013":      3,
    "OWASP_2017":      6,
    "OWASP_2021":     16,
    "SrcFileName":    24,
    "Line":           25,
    "Column":         26,
    "NodeId":         27,
    "Name":           28,
    "DestFileName":   29,
    "DestLine":       30,
    "DestColumn":     31,
    "DestNodeId":     32,
    "DestName":       33,
    "ResultState":    34,
    "ResultSeverity": 35,
    "AssignedTo":     36,
    "Comment":        37,
    "Link":           38,
    "ResultStatus":   39,
    "DetectionDate":  40,
}

# Exact CSV column header names exported by Checkmarx (used when reading .csv):
# Keys are our friendly names; values are the header strings in the CSV.
CX_HEADERS = {
    "Query":           "Query",
    "QueryPath":       "QueryPath",
    "OWASP_2013":      "OWASP Top 10 2013",
    "OWASP_2017":      "OWASP Top 10 2017",
    "OWASP_2021":      "OWASP Top 10 2021",
    "SrcFileName":     "SrcFileName",
    "Line":            "Line",
    "Column":          "Column",
    "NodeId":          "NodeId",
    "Name":            "Name",
    "DestFileName":    "DestFileName",
    "DestLine":        "DestLine",
    "DestColumn":      "DestColumn",
    "DestNodeId":      "DestNodeId",
    "DestName":        "DestName",
    "ResultState":     "Result State",
    "ResultSeverity":  "Result Severity",
    "AssignedTo":      "Assigned To",
    "Comment":         "Comment",
    "Link":            "Link",
    "ResultStatus":    "Result Status",
    "DetectionDate":   "Detection Date",
}

# ---------------------------------------------------------------------------
# Style helpers
# ---------------------------------------------------------------------------

HEADER_FILL   = PatternFill("solid", fgColor="BFBFBF")
HEADER_FONT   = Font(bold=True, size=10)
HEADER_ALIGN  = Alignment(horizontal="center", vertical="center", wrap_text=True)

DATA_FONT     = Font(size=10)
DATA_ALIGN    = Alignment(horizontal="center", vertical="center", wrap_text=True)

THIN_SIDE     = Side(style="thin")
THIN_BORDER   = Border(
    left=THIN_SIDE, right=THIN_SIDE,
    top=THIN_SIDE,  bottom=THIN_SIDE
)

# Risk-level colour mapping (background fill)
RISK_COLORS = {
    "Critical": "C00000",   # dark red
    "High":     "FF0000",   # red
    "Medium":   "FFC000",   # amber
    "Low":      "FFFF00",   # yellow
    "Info":     "92D050",   # green
}

def risk_fill(severity: str) -> PatternFill:
    color = RISK_COLORS.get(severity, "FFFFFF")
    return PatternFill("solid", fgColor=color)

# ---------------------------------------------------------------------------
# Build the POC string from Checkmarx flow columns
# ---------------------------------------------------------------------------

def build_poc(row_data: dict) -> str:
    src  = row_data.get("SrcFileName") or ""
    line = row_data.get("Line") or ""
    name = row_data.get("Name") or ""
    dst  = row_data.get("DestFileName") or ""
    dl   = row_data.get("DestLine") or ""
    dn   = row_data.get("DestName") or ""

    parts = []
    if src:
        parts.append(f"Source: {src} [Line {line}] → {name}")
    if dst:
        parts.append(f"Sink:   {dst} [Line {dl}] → {dn}")
    return "\n".join(parts) if parts else "N/A"

# ---------------------------------------------------------------------------
# Pick best OWASP category string from available columns
# ---------------------------------------------------------------------------

def pick_owasp(row_data: dict) -> str:
    for key in ("OWASP_2021", "OWASP_2017", "OWASP_2013"):
        val = row_data.get(key)
        if val and str(val).strip().lower() not in ("none", ""):
            return str(val).strip()
    return "N/A"

# ---------------------------------------------------------------------------
# Severity ordering helper
# ---------------------------------------------------------------------------

SEV_ORDER = {"Critical": 5, "High": 4, "Medium": 3, "Low": 2, "Info": 1, "": 0}

def highest_severity(sevs: list[str]) -> str:
    """Return the highest severity from a list."""
    return max(sevs, key=lambda s: SEV_ORDER.get(s, 0), default="")


# ---------------------------------------------------------------------------
# Group / deduplicate vulnerabilities by Query name
# ---------------------------------------------------------------------------

def group_vulnerabilities(cx_rows: list[dict]) -> list[dict]:
    """
    Collapse rows that share the same Query (vulnerability type) into one.

    Aggregation rules per field:
      - ResultSeverity  : highest severity wins
      - ResultStatus    : unique values joined with " / "
      - ResultState     : unique values joined with " / "
      - OWASP_*         : first non-None value
      - QueryPath       : first value (same per query type)
      - Link            : first non-empty value
      - Comment         : unique, non-None values concatenated
      - SrcFileName     : all unique files listed (for Affected Assets)
      - POC             : each unique Source→Sink flow numbered and listed
    """
    from collections import OrderedDict

    groups: OrderedDict[str, dict] = OrderedDict()

    for row in cx_rows:
        key = str(row.get("Query") or "Unknown").strip()

        if key not in groups:
            # Seed with copies of scalar fields
            groups[key] = {
                "Query":          key,
                "QueryPath":      row.get("QueryPath") or "",
                "OWASP_2021":     row.get("OWASP_2021"),
                "OWASP_2017":     row.get("OWASP_2017"),
                "OWASP_2013":     row.get("OWASP_2013"),
                "Link":           row.get("Link") or "",
                # Accumulator lists
                "_severities":    [],
                "_statuses":      [],
                "_states":        [],
                "_comments":      [],
                "_src_files":     [],    # unique affected files
                "_poc_flows":     [],    # unique (src_file, line, name, dst_file, dl, dn) tuples
            }

        g = groups[key]

        # Accumulate severity / status / state
        sev = str(row.get("ResultSeverity") or "").strip()
        if sev:
            g["_severities"].append(sev)

        stat = str(row.get("ResultStatus") or "").strip()
        if stat and stat not in g["_statuses"]:
            g["_statuses"].append(stat)

        state = str(row.get("ResultState") or "").strip()
        if state and state not in g["_states"]:
            g["_states"].append(state)

        # Comments
        comment = str(row.get("Comment") or "").strip()
        if comment and comment.lower() != "none" and comment not in g["_comments"]:
            g["_comments"].append(comment)

        # Affected source files
        src = str(row.get("SrcFileName") or "").strip()
        if src and src not in g["_src_files"]:
            g["_src_files"].append(src)

        # POC flows (unique tuples)
        flow = (
            str(row.get("SrcFileName")  or "").strip(),
            str(row.get("Line")         or "").strip(),
            str(row.get("Name")         or "").strip(),
            str(row.get("DestFileName") or "").strip(),
            str(row.get("DestLine")     or "").strip(),
            str(row.get("DestName")     or "").strip(),
        )
        if any(flow) and flow not in g["_poc_flows"]:
            g["_poc_flows"].append(flow)

        # Prefer first non-empty link
        if not g["Link"]:
            g["Link"] = str(row.get("Link") or "").strip()

    # ── Resolve accumulators into final scalar fields ─────────────────────
    result = []
    for key, g in groups.items():
        # Severity: highest across all occurrences
        g["ResultSeverity"] = highest_severity(g["_severities"])
        g["ResultStatus"]   = " / ".join(g["_statuses"])  or "N/A"
        g["ResultState"]    = " / ".join(g["_states"])    or "N/A"
        g["Comment"]        = "; ".join(g["_comments"])   or ""

        # Affected assets: all unique files, one per line
        g["SrcFileName"] = "\n".join(
            f"{i+1}. {f}" for i, f in enumerate(g["_src_files"])
        ) if g["_src_files"] else "N/A"

        # POC: numbered list of all unique flows
        poc_parts = []
        for i, (sf, ln, nm, df, dl, dn) in enumerate(g["_poc_flows"], 1):
            entry_parts = []
            if sf:
                entry_parts.append(f"  Source: {sf} [Line {ln}] → {nm}")
            if df:
                entry_parts.append(f"  Sink:   {df} [Line {dl}] → {dn}")
            if entry_parts:
                poc_parts.append(f"[{i}]\n" + "\n".join(entry_parts))
        g["_poc_combined"] = "\n".join(poc_parts) if poc_parts else "N/A"

        # Count for summary
        g["_occurrence_count"] = len(g["_poc_flows"])

        result.append(g)

    return result



def detect_tech_stack(cx_rows: list[dict]) -> list[dict]:
    """
    Infer tech stack entries from QueryPath language prefixes and source
    file extensions.  Returns a list of dicts with keys:
        srno, tech_stack, open_port, services
    """
    import os as _os

    # Language from QueryPath prefix  (e.g. "CSharp\\Cx\\..." → C#)
    LANG_MAP = {
        "csharp":     "C# / .NET",
        "javascript": "JavaScript",
        "java":       "Java",
        "python":     "Python",
        "php":        "PHP",
        "go":         "Go",
        "kotlin":     "Kotlin",
        "swift":      "Swift",
        "typescript": "TypeScript",
        "vbscript":   "VBScript",
        "plsql":      "PL/SQL",
        "apex":       "Apex (Salesforce)",
        "ruby":       "Ruby",
        "scala":      "Scala",
    }

    # Extension → framework/tech hint
    EXT_MAP = {
        ".cshtml": "ASP.NET MVC (Razor Views)",
        ".aspx":   "ASP.NET Web Forms",
        ".ashx":   "ASP.NET HTTP Handlers",
        ".cs":     "C# / ASP.NET",
        ".vb":     "VB.NET",
        ".js":     "JavaScript",
        ".ts":     "TypeScript",
        ".jsx":    "React (JSX)",
        ".tsx":    "React (TSX)",
        ".vue":    "Vue.js",
        ".py":     "Python",
        ".java":   "Java",
        ".kt":     "Kotlin",
        ".php":    "PHP",
        ".rb":     "Ruby",
        ".go":     "Go",
        ".swift":  "Swift",
        ".rs":     "Rust",
        ".cpp":    "C++",
        ".c":      "C",
        ".scala":  "Scala",
        ".sql":    "SQL",
        ".xml":    "XML / Config",
        ".json":   "JSON / Config",
        ".yaml":   "YAML / Config",
        ".yml":    "YAML / Config",
        ".tf":     "Terraform (IaC)",
    }

    langs_found = set()
    frameworks_found = set()

    for row in cx_rows:
        qp = str(row.get("QueryPath") or "")
        # First segment of QueryPath is the language
        first_seg = qp.split("\\")[0].lower()
        if first_seg in LANG_MAP:
            langs_found.add(LANG_MAP[first_seg])

        for path_col in ("SrcFileName", "DestFileName"):
            fp = str(row.get(path_col) or "")
            if fp:
                ext = _os.path.splitext(fp)[1].lower()
                if ext in EXT_MAP:
                    frameworks_found.add(EXT_MAP[ext])

    # Merge: remove duplicates already captured by lang (e.g. "C# / ASP.NET" ⊇ "C# / .NET")
    all_tech = set(langs_found) | set(frameworks_found)

    # Collapse obvious redundancies
    if "ASP.NET MVC (Razor Views)" in all_tech:
        all_tech.discard("C# / .NET")    # already implied
        all_tech.discard("C# / ASP.NET")
        all_tech.add("C# / ASP.NET MVC")
    elif "C# / ASP.NET" in all_tech:
        all_tech.discard("C# / .NET")

    tech_str = ", ".join(sorted(all_tech))

    return [{
        "srno":       1,
        "tech_stack": tech_str or "N/A",
        "open_port":  "N/A",
        "services":   "N/A",
    }]


# ---------------------------------------------------------------------------
# Fill the Tech Stack sheet
# ---------------------------------------------------------------------------

def write_tech_stack(ws_tech, tech_entries: list[dict]):
    """
    Populate the 'Tech Stack' sheet.
    Template layout:
      Row 6  → header  (Sr.no | Tech Stack | [C3-C4 empty] | Open Port | Services)
      Row 7+ → data
    """
    # Find the header row (contains 'Sr.no' or 'Sr. No')
    header_row = None
    for r in range(1, ws_tech.max_row + 3):
        for c in range(1, ws_tech.max_column + 1):
            val = str(ws_tech.cell(row=r, column=c).value or "").lower().replace(" ", "")
            if "srno" in val:
                header_row = r
                break
        if header_row:
            break
    if not header_row:
        header_row = 6

    data_start = header_row + 1

    # Capture header-row style for reuse
    HEADER_FILL_TS = PatternFill("solid", fgColor="808080")
    HEADER_FONT_TS = Font(bold=True, size=10)
    HEADER_ALIGN_TS = Alignment(horizontal="left", vertical="center", wrap_text=True)

    DATA_FONT_TS  = Font(size=10)
    DATA_ALIGN_TS = Alignment(horizontal="left", vertical="center", wrap_text=True)

    # Delete any existing data rows below the header
    for r in range(ws_tech.max_row, data_start - 1, -1):
        ws_tech.delete_rows(r)

    # Column positions matching the template:
    #   C1 = Sr.no, C2 = Tech Stack, C5 = Open Port, C6 = Services
    COL_SRNO   = 1
    COL_TECH   = 2
    COL_PORT   = 5
    COL_SVC    = 6

    for idx, entry in enumerate(tech_entries, start=1):
        r = data_start + idx - 1

        data_map = {
            COL_SRNO: idx,
            COL_TECH: entry["tech_stack"],
            COL_PORT: entry["open_port"],
            COL_SVC:  entry["services"],
        }

        for c, value in data_map.items():
            cell = ws_tech.cell(row=r, column=c, value=value)
            cell.font      = DATA_FONT_TS
            cell.alignment = DATA_ALIGN_TS
            cell.border    = THIN_BORDER

        # Rough row height
        lines = str(entry["tech_stack"]).count(",") // 3 + 2
        ws_tech.row_dimensions[r].height = max(30, lines * 15)

    print(f"[✓] Tech Stack sheet updated with {len(tech_entries)} entr{'y' if len(tech_entries)==1 else 'ies'}.")


# ---------------------------------------------------------------------------
# Read the Checkmarx report  (auto-detects .csv or .xlsx)
# ---------------------------------------------------------------------------

def _sniff_csv(path: str):
    """
    Detect CSV delimiter and encoding.
    Tries UTF-8-BOM first (common Checkmarx export), falls back to latin-1.
    Returns (encoding, delimiter).
    """
    import csv as _csv

    for enc in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            with open(path, "r", encoding=enc, newline="") as f:
                sample = f.read(4096)
            dialect = _csv.Sniffer().sniff(sample, delimiters=",;\t")
            return enc, dialect.delimiter
        except Exception:
            continue
    # Fallback: UTF-8 + comma
    return "utf-8-sig", ","


def _read_csv(path: str) -> list[dict]:
    """Parse a Checkmarx CSV export into a list of friendly-key dicts."""
    import csv as _csv

    encoding, delimiter = _sniff_csv(path)
    print(f"[→] CSV detected  — encoding={encoding}, delimiter={repr(delimiter)}")

    rows = []
    with open(path, "r", encoding=encoding, newline="") as f:
        reader = _csv.DictReader(f, delimiter=delimiter)

        # Normalise the CSV headers (strip whitespace / BOM remnants)
        raw_headers = reader.fieldnames or []
        norm_headers = {h.strip(): h for h in raw_headers}

        # Build a lookup:  friendly_name → actual CSV column name
        col_map = {}
        missing = []
        for friendly, csv_header in CX_HEADERS.items():
            # Try exact match first, then case-insensitive
            if csv_header in norm_headers:
                col_map[friendly] = norm_headers[csv_header]
            else:
                ci = {k.lower(): v for k, v in norm_headers.items()}
                if csv_header.lower() in ci:
                    col_map[friendly] = ci[csv_header.lower()]
                else:
                    missing.append(csv_header)

        if missing:
            print(f"[!] Warning: {len(missing)} expected column(s) not found in CSV:")
            for m in missing:
                print(f"      - {m}")
            print("    Available columns:", list(norm_headers.keys()))

        for csv_row in reader:
            row_data = {}
            for friendly, actual_col in col_map.items():
                row_data[friendly] = csv_row.get(actual_col, None) or None
            # Skip completely empty rows
            if all(v is None for v in row_data.values()):
                continue
            rows.append(row_data)

    return rows


def _read_xlsx(path: str) -> list[dict]:
    """Parse a Checkmarx XLSX export into a list of friendly-key dicts."""
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb.active

    rows = []
    for row_idx in range(2, ws.max_row + 1):
        row_data = {}
        for friendly_name, col_idx in CX.items():
            cell_val = ws.cell(row=row_idx, column=col_idx).value
            row_data[friendly_name] = cell_val
        # Skip completely empty rows
        if all(v is None for v in row_data.values()):
            continue
        rows.append(row_data)

    return rows


def read_checkmarx(path: str) -> list[dict]:
    """Auto-detect .csv or .xlsx and return list of normalised row dicts."""
    ext = os.path.splitext(path)[1].lower()

    if ext == ".csv":
        rows = _read_csv(path)
    elif ext in (".xlsx", ".xls"):
        rows = _read_xlsx(path)
    else:
        # Try to sniff — if it looks like CSV text, parse as CSV
        try:
            rows = _read_csv(path)
            print(f"[!] Unknown extension '{ext}' — parsed as CSV.")
        except Exception:
            rows = _read_xlsx(path)
            print(f"[!] Unknown extension '{ext}' — parsed as XLSX.")

    # Filter rows where Query is None/empty (can happen with CSV trailing lines)
    rows = [r for r in rows if r.get("Query")]

    print(f"[✓] Read {len(rows)} vulnerabilities from Checkmarx report.")
    return rows

# ---------------------------------------------------------------------------
# Copy the template workbook and fill the Vulnerability Details sheet
# ---------------------------------------------------------------------------

def write_output(template_path: str, cx_rows: list[dict], output_path: str):
    wb = openpyxl.load_workbook(template_path)

    # ── Group duplicate vulnerabilities ──────────────────────────────────
    original_count = len(cx_rows)
    cx_rows = group_vulnerabilities(cx_rows)
    print(f"[✓] Grouped {original_count} rows → {len(cx_rows)} unique vulnerabilities.")

    # ── Vulnerability Details sheet ─────────────────────────────────────
    ws = wb["Vulnerability Details"]

    # Find the first real header row (contains "Sr. No")
    header_row = None
    for r in range(1, 10):
        for c in range(1, ws.max_column + 1):
            if ws.cell(row=r, column=c).value == "Sr. No":
                header_row = r
                break
        if header_row:
            break

    if not header_row:
        print("[WARN] Could not find header row – defaulting to row 3.")
        header_row = 3

    data_start = header_row + 1

    # Clear existing sample data rows (keep template formatting intact on row 4
    # by using it as a style source, then overwrite).
    # We'll copy style from the first data row in the template.
    style_row = data_start  # row 4 in the template

    def get_cell_styles(ws, row):
        """Return a list of style dicts for each column in the row."""
        styles = {}
        for c in range(1, ws.max_column + 1):
            cell = ws.cell(row=row, column=c)
            styles[c] = {
                "font":      copy.copy(cell.font),
                "alignment": copy.copy(cell.alignment),
                "border":    copy.copy(cell.border),
            }
        return styles

    template_styles = get_cell_styles(ws, style_row)

    # Delete all existing data rows (keep only header rows)
    max_existing = ws.max_row
    for r in range(max_existing, data_start - 1, -1):
        ws.delete_rows(r)

    # ── Write data rows ──────────────────────────────────────────────────
    NUM_COLS = 19  # columns A..S

    for idx, row_data in enumerate(cx_rows, start=1):
        r = data_start + idx - 1

        severity   = str(row_data.get("ResultSeverity") or "").strip()
        status     = str(row_data.get("ResultStatus") or "").strip()
        query      = str(row_data.get("Query") or "").strip()
        owasp      = pick_owasp(row_data)
        # Use pre-combined POC if grouping was done, else build single-flow POC
        poc        = row_data.get("_poc_combined") or build_poc(row_data)
        link       = str(row_data.get("Link") or "").strip()
        src_file   = str(row_data.get("SrcFileName") or "").strip()
        comment    = str(row_data.get("Comment") or "").strip()
        state      = str(row_data.get("ResultState") or "").strip()
        query_path = str(row_data.get("QueryPath") or "").strip()
        occurrence = row_data.get("_occurrence_count", "")

        # Map columns
        cell_values = {
            1:  idx,          # Sr. No
            2:  query,        # Vulnerability Title
            3:  severity,     # Risk Level
            4:  status,       # Status
            5:  "",           # CVSS Score  (not available)
            6:  "",           # DREAD Score (not available)
            7:  owasp,        # OWASP Category
            8:  f"{query_path}" + (f" ({occurrence} occurrences)" if occurrence else ""),
            9:  poc,          # POC
            10: "",           # Replication Effort
            11: "",           # Impact
            12: link,         # Vulnerable URLs / IPs
            13: src_file,     # Affected Assets
            14: "",           # Remediation recommendation
            15: "",           # Remediation Effort
            16: link,         # References
            17: "",           # Client Justification
            18: comment if comment.lower() not in ("none", "") else "",
            19: state,        # Remarks
        }

        rfill = risk_fill(severity)

        for c, value in cell_values.items():
            cell = ws.cell(row=r, column=c, value=value)

            # Apply base style from template (if available)
            if c in template_styles:
                cell.font      = copy.copy(template_styles[c]["font"])
                cell.alignment = copy.copy(template_styles[c]["alignment"])
                cell.border    = copy.copy(template_styles[c]["border"])
            else:
                cell.font      = DATA_FONT
                cell.alignment = DATA_ALIGN
                cell.border    = THIN_BORDER

            # Risk-level column gets colour fill
            if c == 3 and severity:
                cell.fill = rfill
                # Use dark font for light backgrounds
                if severity in ("Low", "Info"):
                    cell.font = Font(size=10, bold=True, color="000000")
                else:
                    cell.font = Font(size=10, bold=True, color="FFFFFF")

        # Auto-height: rough estimate – 15pt per line, min 30
        lines = max(
            str(v).count("\n") + 1
            for v in cell_values.values() if v
        ) if any(cell_values.values()) else 1
        ws.row_dimensions[r].height = max(30, lines * 15)

    # ── Preserve column widths from template ─────────────────────────────
    # (already preserved because we loaded the template)

    # ── Tech Stack sheet ─────────────────────────────────────────────────
    if "Tech Stack" in wb.sheetnames:
        ws_tech = wb["Tech Stack"]
        tech_entries = detect_tech_stack(cx_rows)
        write_tech_stack(ws_tech, tech_entries)
    else:
        print("[WARN] 'Tech Stack' sheet not found in template – skipping.")

    # ── Save ────────────────────────────────────────────────────────────
    wb.save(output_path)
    print(f"[✓] Output saved → {output_path}")

# ---------------------------------------------------------------------------
# Summary statistics
# ---------------------------------------------------------------------------

def print_summary(cx_rows: list[dict]):
    from collections import Counter

    # cx_rows at this point are the RAW ungrouped rows (passed from main)
    # We re-group here just to get occurrence counts for the summary
    grouped = group_vulnerabilities(cx_rows)

    sev_count  = Counter()
    stat_count = Counter()
    for r in cx_rows:
        sev  = str(r.get("ResultSeverity") or "Unknown").strip()
        stat = str(r.get("ResultStatus") or "Unknown").strip()
        sev_count[sev]  += 1
        stat_count[stat] += 1

    print("\n" + "=" * 60)
    print("  CHECKMARX → EXAMPLE FORMAT  |  CONVERSION SUMMARY")
    print("=" * 60)
    print(f"  Raw rows in Checkmarx file    : {len(cx_rows)}")
    print(f"  Unique vulnerabilities (rows) : {len(grouped)}")
    print(f"  Compression ratio             : {len(cx_rows)}:{len(grouped)}")

    print("\n  Grouped Vulnerabilities (occurrences each):")
    for g in grouped:
        cnt = g.get("_occurrence_count", 1)
        sev = g.get("ResultSeverity", "?")
        name = g.get("Query", "?")
        print(f"    [{sev:<8}]  {cnt:>3}x  {name}")

    print("\n  By Severity (raw rows):")
    for sev in ["Critical", "High", "Medium", "Low", "Info"]:
        if sev in sev_count:
            bar = "█" * sev_count[sev]
            print(f"    {sev:<10} {sev_count[sev]:>3}  {bar}")

    print("\n  By Status:")
    for stat, cnt in stat_count.most_common():
        bar = "█" * cnt
        print(f"    {stat:<15} {cnt:>3}  {bar}")

    print("=" * 60)

# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Convert Checkmarx SAST report (.csv or .xlsx) to NetSentries example format."
    )
    parser.add_argument(
        "--input", "-i",
        default=None,
        help="Path to the Checkmarx report file (.csv or .xlsx). "
             "If omitted the script auto-searches for checkmarx.csv or checkmarx.xlsx in the current folder."
    )
    parser.add_argument(
        "--template", "-t",
        default="example file.xlsx",
        help="Path to the NetSentries template file (default: 'example file.xlsx')"
    )
    parser.add_argument(
        "--output", "-o",
        default="output_report.xlsx",
        help="Path for the generated output file (default: output_report.xlsx)"
    )
    args = parser.parse_args()

    # ── Auto-detect input file if not specified ───────────────────────────
    if args.input is None:
        for candidate in ("checkmarx.csv", "checkmarx.xlsx", "checkmarx.xls"):
            if os.path.isfile(candidate):
                args.input = candidate
                print(f"[→] Auto-detected input file : {candidate}")
                break
        if args.input is None:
            sys.exit(
                "[ERROR] No input file found. Place your Checkmarx export in the same folder\n"
                "        (checkmarx.csv or checkmarx.xlsx) or use --input <path>"
            )

    # Validate inputs
    for label, path in [("Input", args.input), ("Template", args.template)]:
        if not os.path.isfile(path):
            sys.exit(f"[ERROR] {label} file not found: {path}")

    print(f"[→] Reading Checkmarx report : {args.input}")
    print(f"[→] Using template           : {args.template}")
    print(f"[→] Output will be written   : {args.output}")
    print()

    cx_rows = read_checkmarx(args.input)
    write_output(args.template, cx_rows, args.output)
    print_summary(cx_rows)
    print(f"\n[✓] Done! Open '{args.output}' to review the converted report.")

if __name__ == "__main__":
    main()
