"""
checkmarx_to_example.py
-----------------------
Converts a Checkmarx SAST report (checkmarx.xlsx) into the
NetSentries "example file.xlsx" report format.

Dependencies (local / no internet required):
    pip install openpyxl      (already ships with most Python distros,
                               or install from a local wheel)

Usage:
    python checkmarx_to_example.py
        --input  checkmarx.xlsx
        --template "example file.xlsx"
        --output  output_report.xlsx

All three arguments have default values matching the files in the
same directory, so a plain `python checkmarx_to_example.py` works too.
"""

import argparse
import copy
import os
import sys
from datetime import datetime

try:
    import openpyxl
    from openpyxl.styles import (
        PatternFill, Font, Alignment, Border, Side, GradientFill
    )
    from openpyxl.utils import get_column_letter
except ImportError:
    sys.exit(
        "[ERROR] openpyxl is not installed.\n"
        "Install it offline with:  pip install openpyxl\n"
        "(or copy the openpyxl wheel to this machine and install it)"
    )

# ---------------------------------------------------------------------------
# Column mapping:  Checkmarx column  →  Example "Vulnerability Details" column
# ---------------------------------------------------------------------------
# The example sheet headers start at row 3, data from row 4.
# We'll derive as much as possible from the Checkmarx data.
# Columns in the example sheet (1-indexed):
#   1  Sr. No
#   2  Vulnerability Title        ← Query (col 1)
#   3  Risk Level                 ← Result Severity (col 35)
#   4  Status                     ← Result Status  (col 39)
#   5  CVSS Score v 4.0           ← (not in Checkmarx – left empty)
#   6  DREAD Risk Score           ← (not in Checkmarx – left empty)
#   7  OWASP/ WASC/ CWE Category  ← best available OWASP column (16, 6, 3, 8)
#   8  Abstract                   ← QueryPath (col 2)  — best description available
#   9  POC                        ← SrcFileName:Line → DestFileName:DestLine (cols 24-33)
#  10  Replication Effort         ← (left empty)
#  11  Impact                     ← (left empty)
#  12  Vulnerable URLs/ IPs       ← Link (col 38)
#  13  Affected Assets            ← SrcFileName (col 24)
#  14  Remediation recommendation ← (left empty)
#  15  Remediation Effort         ← (left empty)
#  16  References                 ← Link (col 38)
#  17  Client Justification       ← (left empty)
#  18  NetSentries Comments       ← Comment (col 37)
#  19  Remarks                    ← Result State (col 34)

# Checkmarx column indices (1-based, used when reading .xlsx):
CX = {
    "Query":           1,
    "QueryPath":       2,
    "OWASP_2013":      3,
    "OWASP_2017":      6,
    "OWASP_2021":     16,
    "SrcFileName":    24,
    "Line":           25,
    "Column":         26,
    "NodeId":         27,
    "Name":           28,
    "DestFileName":   29,
    "DestLine":       30,
    "DestColumn":     31,
    "DestNodeId":     32,
    "DestName":       33,
    "ResultState":    34,
    "ResultSeverity": 35,
    "AssignedTo":     36,
    "Comment":        37,
    "Link":           38,
    "ResultStatus":   39,
    "DetectionDate":  40,
}

# Exact CSV column header names exported by Checkmarx (used when reading .csv):
# Keys are our friendly names; values are the header strings in the CSV.
CX_HEADERS = {
    "Query":           "Query",
    "QueryPath":       "QueryPath",
    "OWASP_2013":      "OWASP Top 10 2013",
    "OWASP_2017":      "OWASP Top 10 2017",
    "OWASP_2021":      "OWASP Top 10 2021",
    "SrcFileName":     "SrcFileName",
    "Line":            "Line",
    "Column":          "Column",
    "NodeId":          "NodeId",
    "Name":            "Name",
    "DestFileName":    "DestFileName",
    "DestLine":        "DestLine",
    "DestColumn":      "DestColumn",
    "DestNodeId":      "DestNodeId",
    "DestName":        "DestName",
    "ResultState":     "Result State",
    "ResultSeverity":  "Result Severity",
    "AssignedTo":      "Assigned To",
    "Comment":         "Comment",
    "Link":            "Link",
    "ResultStatus":    "Result Status",
    "DetectionDate":   "Detection Date",
}

# ---------------------------------------------------------------------------
# Style helpers
# ---------------------------------------------------------------------------

HEADER_FILL   = PatternFill("solid", fgColor="BFBFBF")
HEADER_FONT   = Font(bold=True, size=10)
HEADER_ALIGN  = Alignment(horizontal="center", vertical="center", wrap_text=True)

DATA_FONT     = Font(size=10)
DATA_ALIGN    = Alignment(horizontal="center", vertical="center", wrap_text=True)

THIN_SIDE     = Side(style="thin")
THIN_BORDER   = Border(
    left=THIN_SIDE, right=THIN_SIDE,
    top=THIN_SIDE,  bottom=THIN_SIDE
)

# Risk-level colour mapping (background fill)
RISK_COLORS = {
    "Critical": "C00000",   # dark red
    "High":     "FF0000",   # red
    "Medium":   "FFC000",   # amber
    "Low":      "FFFF00",   # yellow
    "Info":     "92D050",   # green
}

def risk_fill(severity: str) -> PatternFill:
    color = RISK_COLORS.get(severity, "FFFFFF")
    return PatternFill("solid", fgColor=color)

# ---------------------------------------------------------------------------
# Security references  (external OWASP / CWE / NIST links per vuln type)
# ---------------------------------------------------------------------------
#
# Keys are matched case-insensitively against the Query name.
# Values are multi-line strings of authoritative external references.
# Add more entries here as needed.

SECURITY_REFERENCES = {
    "xss":              "OWASP: https://owasp.org/www-community/attacks/xss/\nCWE-79: https://cwe.mitre.org/data/definitions/79.html\nOWASP Top 10 A03:2021 - Injection",
    "stored xss":       "OWASP: https://owasp.org/www-community/attacks/xss/\nCWE-79: https://cwe.mitre.org/data/definitions/79.html\nOWASP Top 10 A03:2021 - Injection",
    "reflected xss":    "OWASP: https://owasp.org/www-community/attacks/xss/\nCWE-79: https://cwe.mitre.org/data/definitions/79.html\nOWASP Top 10 A03:2021 - Injection",
    "dom xss":          "OWASP: https://owasp.org/www-community/attacks/DOM_Based_XSS\nCWE-79: https://cwe.mitre.org/data/definitions/79.html",
    "code injection":   "OWASP: https://owasp.org/www-community/attacks/Code_Injection\nCWE-94: https://cwe.mitre.org/data/definitions/94.html\nOWASP Top 10 A03:2021 - Injection",
    "sql injection":    "OWASP: https://owasp.org/www-community/attacks/SQL_Injection\nCWE-89: https://cwe.mitre.org/data/definitions/89.html\nOWASP Top 10 A03:2021 - Injection",
    "path traversal":   "OWASP: https://owasp.org/www-community/attacks/Path_Traversal\nCWE-22: https://cwe.mitre.org/data/definitions/22.html\nOWASP Top 10 A01:2021 - Broken Access Control",
    "directory traversal": "OWASP: https://owasp.org/www-community/attacks/Path_Traversal\nCWE-22: https://cwe.mitre.org/data/definitions/22.html",
    "httponlycookies":  "OWASP: https://owasp.org/www-community/HttpOnly\nCWE-1004: https://cwe.mitre.org/data/definitions/1004.html\nOWASP Top 10 A05:2021 - Security Misconfiguration",
    "cookie":           "OWASP: https://owasp.org/www-community/HttpOnly\nCWE-614: https://cwe.mitre.org/data/definitions/614.html",
    "csrf":             "OWASP: https://owasp.org/www-community/attacks/csrf\nCWE-352: https://cwe.mitre.org/data/definitions/352.html\nOWASP Top 10 A01:2021 - Broken Access Control",
    "open redirect":    "OWASP: https://cheatsheetseries.owasp.org/cheatsheets/Unvalidated_Redirects_and_Forwards_Cheat_Sheet.html\nCWE-601: https://cwe.mitre.org/data/definitions/601.html",
    "command injection":"OWASP: https://owasp.org/www-community/attacks/Command_Injection\nCWE-77: https://cwe.mitre.org/data/definitions/77.html\nOWASP Top 10 A03:2021 - Injection",
    "xxe":              "OWASP: https://owasp.org/www-community/vulnerabilities/XML_External_Entity_(XXE)_Processing\nCWE-611: https://cwe.mitre.org/data/definitions/611.html",
    "ssrf":             "OWASP: https://owasp.org/www-community/attacks/Server_Side_Request_Forgery\nCWE-918: https://cwe.mitre.org/data/definitions/918.html",
    "insecure deserialization": "OWASP: https://owasp.org/www-community/vulnerabilities/Deserialization_of_untrusted_data\nCWE-502: https://cwe.mitre.org/data/definitions/502.html",
    "ldap injection":   "OWASP: https://owasp.org/www-community/attacks/LDAP_Injection\nCWE-90: https://cwe.mitre.org/data/definitions/90.html",
    "hardcoded":        "CWE-798: https://cwe.mitre.org/data/definitions/798.html\nOWASP Top 10 A02:2021 - Cryptographic Failures",
    "sensitive data":   "OWASP Top 10 A02:2021 - Cryptographic Failures\nhttps://owasp.org/Top10/A02_2021-Cryptographic_Failures/",
}


def lookup_references(query: str) -> str:
    """
    Return external security reference URLs for a given vulnerability query name.
    Matches case-insensitively against keywords in SECURITY_REFERENCES.
    Falls back to a generic OWASP link if nothing matches.
    """
    q_lower = query.lower()
    # Longest-key-first so more specific matches win
    for keyword in sorted(SECURITY_REFERENCES, key=len, reverse=True):
        if keyword in q_lower:
            return SECURITY_REFERENCES[keyword]
    # Generic fallback
    return "OWASP Top 10: https://owasp.org/www-project-top-ten/\nCWE List: https://cwe.mitre.org/"

# ---------------------------------------------------------------------------
# Remediation recommendations  (built-in, keyed by vulnerability title)
# ---------------------------------------------------------------------------
#
# Keys are matched case-insensitively (longest match wins).
# Each value is a concise, actionable remediation for the analyst report.

REMEDIATION = {
    # ── DOM / XSS family ────────────────────────────────────────────────────
    "client dom code injection": (
        "Avoid passing untrusted data to JavaScript execution sinks such as eval(), "
        "innerHTML, document.write(), or setTimeout(string). "
        "Use textContent or innerText for rendering user-supplied content. "
        "Apply a strict Content Security Policy (CSP) that blocks inline scripts and "
        "restricts script sources to trusted origins."
    ),
    "client dom stored xss": (
        "Sanitize all data retrieved from storage (localStorage, sessionStorage, IndexedDB, "
        "cookies, or server-supplied JSON) before rendering it in the DOM. "
        "Use a vetted sanitization library (e.g., DOMPurify) and encode output "
        "context-appropriately (HTML, JavaScript, URL encoding). "
        "Enforce a strict Content Security Policy (CSP)."
    ),
    "client dom xss": (
        "Avoid writing untrusted data directly to dangerous DOM sinks (innerHTML, "
        "document.write, eval, etc.). "
        "Use safe DOM APIs such as textContent, setAttribute, or createElement. "
        "Apply output encoding appropriate to the context and enforce a Content Security Policy (CSP)."
    ),
    "client hardcoded domain": (
        "Remove hardcoded domain names and base URLs from client-side code. "
        "Use environment-specific configuration files or server-injected variables "
        "to supply endpoint values at runtime. "
        "This prevents accidental exposure of internal infrastructure and eases "
        "migration between environments."
    ),
    "client jquery deprecated symbols": (
        "Upgrade to a supported version of jQuery (3.x or later) and replace all "
        "deprecated API calls (e.g., .live(), .die(), .size(), .bind()) with their "
        "modern equivalents. "
        "Deprecated APIs may contain known security vulnerabilities and will be removed "
        "in future releases."
    ),
    "client privacy violation": (
        "Do not store or transmit Personally Identifiable Information (PII) in "
        "client-side storage (localStorage, sessionStorage, cookies) unless strictly necessary. "
        "Minimize data collected, apply appropriate expiry, and encrypt sensitive values. "
        "Ensure transmission is over HTTPS only."
    ),
    "client use of iframe without sandbox": (
        "Add the sandbox attribute to all <iframe> elements that load third-party or "
        "untrusted content. "
        "Apply the most restrictive sandbox policy possible (e.g., sandbox=\"allow-scripts allow-same-origin\") "
        "and use the allow-* permissions only when explicitly required. "
        "Also set X-Frame-Options and Content-Security-Policy frame-ancestors headers."
    ),

    # ── Memory / data exposure ───────────────────────────────────────────────
    "heap inspection": (
        "Avoid storing sensitive data (passwords, keys, PII) in long-lived strings or "
        "byte arrays. Use secure containers (e.g., SecureString in .NET, char[] in Java) "
        "and zero out memory immediately after use. "
        "Do not log or serialize objects that contain sensitive fields."
    ),

    # ── Cookie security ──────────────────────────────────────────────────────
    "httponlycookies": (
        "Set the HttpOnly flag on all session and authentication cookies to prevent "
        "client-side JavaScript from accessing them. "
        "In ASP.NET, set httpOnlyCookies=\"true\" in <httpCookies> in Web.config, "
        "or set HttpOnly = true on each HttpCookie object. "
        "Additionally apply the Secure and SameSite=Strict flags."
    ),
    "unprotected cookie": (
        "Ensure all sensitive cookies are issued with the Secure, HttpOnly, and "
        "SameSite=Strict (or Lax) attributes. "
        "The Secure flag prevents transmission over plain HTTP; "
        "HttpOnly blocks JavaScript access; SameSite mitigates CSRF. "
        "Validate cookie integrity with an HMAC signature for critical cookies."
    ),

    # ── Injection ────────────────────────────────────────────────────────────
    "ldap injection": (
        "Use parameterized LDAP APIs or a vetted LDAP escaping library to handle "
        "user-supplied input in filter strings. "
        "Escape special LDAP characters (*, (, ), \\, NUL) before including them in "
        "queries. Enforce least-privilege service accounts for LDAP binds and "
        "validate/whitelist all input values."
    ),
    "stored ldap injection": (
        "Sanitize and escape LDAP special characters in any data read from persistent "
        "storage before using it in LDAP filter expressions. "
        "Prefer parameterized LDAP frameworks; never concatenate raw stored values "
        "into LDAP queries. Apply input validation at storage time as a defence-in-depth measure."
    ),
    "log forging": (
        "Sanitize all user-supplied data written to log files by removing or encoding "
        "newline characters (\\n, \\r), CRLF sequences, and other control characters. "
        "Use a structured logging library that separates message templates from "
        "user-provided values so they cannot alter log format or inject false entries."
    ),
    "path traversal": (
        "Validate and canonicalize file paths before use. "
        "Resolve the absolute path with Path.GetFullPath() (or equivalent) and verify "
        "it starts with the expected base directory. "
        "Use a whitelist of allowed file names or extensions; reject any path "
        "containing sequences such as ../, ..\\ or URL-encoded variants. "
        "Avoid passing user input directly to file system APIs."
    ),

    # ── Headers / transport ──────────────────────────────────────────────────
    "missing hsts header": (
        "Add the Strict-Transport-Security (HSTS) response header to force browsers "
        "to use HTTPS for all future requests. "
        "Recommended value: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload. "
        "Ensure the site is fully HTTPS before enabling preload, and register the domain "
        "with the HSTS preload list."
    ),

    # ── Input validation ─────────────────────────────────────────────────────
    "no request validation": (
        "Enable ASP.NET request validation (validateRequest=\"true\") to automatically "
        "detect potentially dangerous input. "
        "Do not disable request validation globally; if specific endpoints need raw HTML "
        "input, validate and sanitize that input explicitly using a library such as "
        "HtmlSanitizer or AntiXssEncoder before processing or persisting."
    ),

    # ── Redirect ─────────────────────────────────────────────────────────────
    "open redirect": (
        "Validate redirect targets against a strict whitelist of allowed internal URLs. "
        "Do not use user-supplied query parameters directly in redirects. "
        "If external redirects are required, implement a confirmation page or signed "
        "redirect tokens. Use relative paths for internal redirects where possible."
    ),

    # ── Secrets / passwords ──────────────────────────────────────────────────
    "password in comment": (
        "Remove all passwords, secrets, and credentials from source code comments immediately. "
        "Rotate any exposed credentials. "
        "Store secrets in a dedicated secrets manager (e.g., Azure Key Vault, HashiCorp Vault) "
        "or environment variables, and enforce pre-commit hooks or SAST scans to "
        "detect secrets before they reach version control."
    ),
    "password in configuration file": (
        "Remove plain-text passwords from configuration files. "
        "Use a secrets management solution (Azure Key Vault, AWS Secrets Manager, "
        "HashiCorp Vault) or encrypted environment variables. "
        "Rotate all exposed credentials immediately and add the configuration file "
        "to .gitignore. Enforce secret scanning in CI/CD pipelines."
    ),
    "use of hardcoded password": (
        "Remove all hardcoded passwords and credentials from source code. "
        "Rotate the exposed credentials immediately. "
        "Store secrets externally in a secrets manager or environment variables "
        "injected at runtime. Implement secret-scanning tools in the CI/CD pipeline "
        "to prevent future occurrences."
    ),

    # ── Privacy ──────────────────────────────────────────────────────────────
    "privacy violation": (
        "Identify all locations where PII (names, emails, SSNs, health data, etc.) "
        "is logged, cached, or exposed in error messages. "
        "Apply data minimization — collect and store only what is strictly necessary. "
        "Mask or redact PII in logs. Ensure data at rest is encrypted and access is "
        "restricted to authorized roles."
    ),

    # ── Prototype pollution ──────────────────────────────────────────────────
    "prototype pollution": (
        "Avoid using recursive merge or deep-clone functions with untrusted objects "
        "without sanitizing keys. "
        "Reject or strip keys such as __proto__, constructor, and prototype before "
        "merging user-supplied objects. "
        "Use Object.create(null) to create dictionaries with no prototype, and "
        "replace vulnerable lodash/merge or jQuery.extend patterns with safe alternatives."
    ),

    # ── XSS (server-side) ────────────────────────────────────────────────────
    "reflected xss all clients": (
        "Encode all user-supplied output using context-appropriate encoding "
        "(HTML entity encoding for HTML context, JavaScript encoding for script context, "
        "URL encoding for URL context). "
        "Use AntiXssEncoder or built-in MVC Html.Encode helpers. "
        "Implement a Content Security Policy (CSP) and enable ASP.NET request validation."
    ),
    "stored xss": (
        "Sanitize user input at the point of storage and encode it at the point of "
        "rendering using context-aware encoding. "
        "Do not trust data retrieved from the database. "
        "Use a vetted HTML sanitizer for rich-text fields and enforce a strict "
        "Content Security Policy (CSP) to limit script execution."
    ),

    # ── SSL / TLS ────────────────────────────────────────────────────────────
    "ssl verification bypass": (
        "Never disable SSL/TLS certificate validation in production code. "
        "Remove any custom TrustManager, HostnameVerifier, or ServicePointManager "
        "callbacks that accept all certificates. "
        "Use the platform's default SSL context. For testing, use a locally trusted CA "
        "rather than bypassing validation. Enforce certificate pinning for high-risk endpoints."
    ),

    # ── SSRF ─────────────────────────────────────────────────────────────────
    "ssrf": (
        "Validate and whitelist all URLs and hostnames before making server-side HTTP requests. "
        "Reject requests to private IP ranges (10.x, 172.16.x, 192.168.x, 127.x, 169.254.x) "
        "and internal hostnames. "
        "Use a DNS rebinding-resistant resolver and enforce egress firewall rules. "
        "Never forward raw user-supplied URLs to backend HTTP clients."
    ),

    # ── Trust boundary ───────────────────────────────────────────────────────
    "trust boundary violation in session variables": (
        "Do not copy unvalidated user input directly into server-side session variables. "
        "Validate and sanitize all data before elevating it from the untrusted "
        "(request) zone to the trusted (session) zone. "
        "Treat session data with the same care as any other persistent store and "
        "re-authenticate users before granting access to sensitive session-backed resources."
    ),

    # ── Target _blank ────────────────────────────────────────────────────────
    "unsafe use of target blank": (
        "Add rel=\"noopener noreferrer\" to all anchor tags that use target=\"_blank\". "
        "Without this, the opened page can access the opener via window.opener and "
        "redirect it (reverse tabnapping). "
        "For links to untrusted external content, also consider adding nofollow."
    ),

    # ── Cryptography ─────────────────────────────────────────────────────────
    "use of broken or risky cryptographic algorithm": (
        "Replace weak or broken algorithms (MD5, SHA-1, DES, RC4, ECB mode) with "
        "modern, vetted alternatives: use SHA-256 or SHA-3 for hashing, AES-256-GCM "
        "for symmetric encryption, and RSA-2048+ or ECC P-256+ for asymmetric operations. "
        "Use a well-maintained cryptographic library and never implement custom cryptography."
    ),

    # ── CSRF ─────────────────────────────────────────────────────────────────
    "csrf": (
        "Implement anti-CSRF tokens (synchronizer token pattern) on all state-changing "
        "requests (POST, PUT, DELETE, PATCH). "
        "In ASP.NET MVC, use the built-in @Html.AntiForgeryToken() helper and "
        "[ValidateAntiForgeryToken] attribute. "
        "Additionally enforce SameSite=Strict or SameSite=Lax on session cookies to "
        "provide defence-in-depth against cross-site request forgery."
    ),

    # ── Deserialization ───────────────────────────────────────────────────────
    "deserialization of untrusted data": (
        "Never deserialize data from untrusted sources using insecure deserializers "
        "(e.g., BinaryFormatter, JavaScriptSerializer with type resolvers, or "
        "Newtonsoft.Json with TypeNameHandling set to All/Auto). "
        "Use safe, schema-based formats (JSON with strict typing, protobuf). "
        "If deserialization of complex objects is required, validate a cryptographic "
        "signature or HMAC on the payload before deserializing, and run the deserializer "
        "in a sandboxed, least-privilege context."
    ),

    # ── Hardcoded credentials ─────────────────────────────────────────────────
    "hardcoded password in connection string": (
        "Remove the hardcoded password from the connection string immediately and rotate "
        "the database credentials. "
        "Store connection strings in a secrets manager (Azure Key Vault, AWS Secrets Manager) "
        "or use integrated/Windows authentication where possible. "
        "In .NET, use the ConfigurationBuilder with environment variables or Azure App "
        "Configuration to inject secrets at runtime without embedding them in code or config files."
    ),

    # ── SQL Injection ─────────────────────────────────────────────────────────
    "sql injection": (
        "Use parameterized queries or prepared statements for all database interactions. "
        "Never concatenate user-supplied input into SQL strings. "
        "In .NET, use SqlCommand with SqlParameter objects, or an ORM such as Entity Framework "
        "with LINQ queries. Apply the principle of least privilege to database accounts "
        "and implement input validation as a secondary defence."
    ),
    "second order sql injection": (
        "Treat all data retrieved from the database as untrusted before using it in "
        "subsequent SQL queries. "
        "Apply parameterized queries or prepared statements at every database interaction, "
        "not just at the point of initial user input. "
        "Audit all code paths where stored data is later used in dynamic SQL construction "
        "and refactor to use parameterized APIs throughout."
    ),

    # ── Weak PRNG ─────────────────────────────────────────────────────────────
    "use of cryptographically weak prng": (
        "Replace all uses of non-cryptographic random number generators "
        "(System.Random, Math.random(), rand()) with a cryptographically secure "
        "alternative: use System.Security.Cryptography.RandomNumberGenerator in .NET, "
        "java.security.SecureRandom in Java, or secrets.token_bytes() in Python. "
        "Cryptographically weak PRNGs must not be used for security-sensitive values "
        "such as tokens, session IDs, nonces, or password reset links."
    ),

    # ── DOM injection (stored) ────────────────────────────────────────────────
    "client dom stored code injection": (
        "Avoid passing data retrieved from persistent client-side storage "
        "(localStorage, sessionStorage, IndexedDB, cookies) into JavaScript execution "
        "sinks such as eval(), Function(), innerHTML, or document.write(). "
        "Sanitize stored values with a vetted library (e.g., DOMPurify) before rendering, "
        "and enforce a strict Content Security Policy (CSP) that disallows unsafe-eval "
        "and unsafe-inline script execution."
    ),

    # ── MVC View Injection ────────────────────────────────────────────────────
    "mvc view injection": (
        "Ensure that all user-supplied data rendered in Razor views is HTML-encoded by "
        "default. Use @Html.Encode() or the Razor @ syntax (which encodes automatically) "
        "instead of @Html.Raw(). "
        "Never pass unvalidated input to @Html.Raw() or HtmlString constructors. "
        "Apply model validation attributes ([Required], [RegularExpression], etc.) and "
        "enable ASP.NET request validation to reject dangerous input at the framework level."
    ),

    # ── Parameter Tampering ───────────────────────────────────────────────────
    "parameter tampering": (
        "Never trust client-supplied parameters for security-sensitive decisions "
        "(prices, roles, record IDs, access flags). "
        "Re-fetch authoritative values from the server-side data store at each request. "
        "Use signed or encrypted tokens (e.g., HMAC, JWT) for any values that must round-trip "
        "through the client. Implement server-side authorization checks that verify "
        "the authenticated user has permission to act on the requested resource."
    ),
}


def lookup_remediation(query: str) -> str:
    """
    Return a built-in remediation recommendation for the given vulnerability name.
    Matches case-insensitively (longest key wins for specificity).
    Returns an empty string if no match is found (analyst fills manually).
    """
    q_lower = query.lower().strip()

    # Exact match first
    if q_lower in REMEDIATION:
        return REMEDIATION[q_lower]

    # Longest substring match
    for key in sorted(REMEDIATION, key=len, reverse=True):
        if key in q_lower or q_lower in key:
            return REMEDIATION[key]

    return ""   # no match — analyst fills in manually


# ---------------------------------------------------------------------------
# Build the POC string from Checkmarx flow columns
# ---------------------------------------------------------------------------

def build_poc(row_data: dict) -> str:
    src  = row_data.get("SrcFileName") or ""
    line = row_data.get("Line") or ""
    name = row_data.get("Name") or ""
    dst  = row_data.get("DestFileName") or ""
    dl   = row_data.get("DestLine") or ""
    dn   = row_data.get("DestName") or ""

    parts = []
    if src:
        parts.append(f"Source: {src} [Line {line}] → {name}")
    if dst:
        parts.append(f"Sink:   {dst} [Line {dl}] → {dn}")
    return "\n".join(parts) if parts else "N/A"

# ---------------------------------------------------------------------------
# Pick best OWASP category string from available columns
# ---------------------------------------------------------------------------

def pick_owasp(row_data: dict) -> str:
    for key in ("OWASP_2021", "OWASP_2017", "OWASP_2013"):
        val = row_data.get(key)
        if val and str(val).strip().lower() not in ("none", ""):
            return str(val).strip()
    return "N/A"

# ---------------------------------------------------------------------------
# Severity ordering helper
# ---------------------------------------------------------------------------

SEV_ORDER = {"Critical": 5, "High": 4, "Medium": 3, "Low": 2, "Info": 1, "": 0}

def highest_severity(sevs: list[str]) -> str:
    """Return the highest severity from a list."""
    return max(sevs, key=lambda s: SEV_ORDER.get(s, 0), default="")


# ---------------------------------------------------------------------------
# Group / deduplicate vulnerabilities by Query name
# ---------------------------------------------------------------------------

def group_vulnerabilities(cx_rows: list[dict]) -> list[dict]:
    """
    Collapse rows that share the same Query (vulnerability type) into one.

    Aggregation rules per field:
      - ResultSeverity  : highest severity wins
      - ResultStatus    : unique values joined with " / "
      - ResultState     : unique values joined with " / "
      - OWASP_*         : first non-None value
      - QueryPath       : first value (same per query type)
      - Link            : first non-empty value
      - Comment         : unique, non-None values concatenated
      - SrcFileName     : all unique files listed (for Affected Assets)
      - POC             : each unique Source→Sink flow numbered and listed
    """
    from collections import OrderedDict

    groups: OrderedDict[str, dict] = OrderedDict()

    for row in cx_rows:
        key = str(row.get("Query") or "Unknown").strip()

        if key not in groups:
            # Seed with copies of scalar fields
            groups[key] = {
                "Query":          key,
                "QueryPath":      row.get("QueryPath") or "",
                "OWASP_2021":     row.get("OWASP_2021"),
                "OWASP_2017":     row.get("OWASP_2017"),
                "OWASP_2013":     row.get("OWASP_2013"),
                "Link":           row.get("Link") or "",
                # Accumulator lists
                "_severities":    [],
                "_statuses":      [],
                "_states":        [],
                "_comments":      [],
                "_src_files":     [],    # unique affected files
                "_poc_flows":     [],    # unique (src_file, line, name, dst_file, dl, dn) tuples
            }

        g = groups[key]

        # Accumulate severity / status / state
        sev = str(row.get("ResultSeverity") or "").strip()
        if sev:
            g["_severities"].append(sev)

        stat = str(row.get("ResultStatus") or "").strip()
        if stat and stat not in g["_statuses"]:
            g["_statuses"].append(stat)

        state = str(row.get("ResultState") or "").strip()
        if state and state not in g["_states"]:
            g["_states"].append(state)

        # Comments
        comment = str(row.get("Comment") or "").strip()
        if comment and comment.lower() != "none" and comment not in g["_comments"]:
            g["_comments"].append(comment)

        # Affected source files
        src = str(row.get("SrcFileName") or "").strip()
        if src and src not in g["_src_files"]:
            g["_src_files"].append(src)

        # POC flows (unique tuples)
        flow = (
            str(row.get("SrcFileName")  or "").strip(),
            str(row.get("Line")         or "").strip(),
            str(row.get("Name")         or "").strip(),
            str(row.get("DestFileName") or "").strip(),
            str(row.get("DestLine")     or "").strip(),
            str(row.get("DestName")     or "").strip(),
        )
        if any(flow) and flow not in g["_poc_flows"]:
            g["_poc_flows"].append(flow)

        # Prefer first non-empty link
        if not g["Link"]:
            g["Link"] = str(row.get("Link") or "").strip()

    # ── Resolve accumulators into final scalar fields ─────────────────────
    result = []
    for key, g in groups.items():
        # Severity: highest across all occurrences
        g["ResultSeverity"] = highest_severity(g["_severities"])
        g["ResultStatus"]   = " / ".join(g["_statuses"])  or "N/A"
        g["ResultState"]    = " / ".join(g["_states"])    or "N/A"
        g["Comment"]        = "; ".join(g["_comments"])   or ""

        # Affected assets: all unique files, one per line
        g["SrcFileName"] = "\n".join(
            f"{i+1}. {f}" for i, f in enumerate(g["_src_files"])
        ) if g["_src_files"] else "N/A"

        # POC: numbered list of all unique flows
        poc_parts = []
        for i, (sf, ln, nm, df, dl, dn) in enumerate(g["_poc_flows"], 1):
            entry_parts = []
            if sf:
                entry_parts.append(f"  Source: {sf} [Line {ln}] → {nm}")
            if df:
                entry_parts.append(f"  Sink:   {df} [Line {dl}] → {dn}")
            if entry_parts:
                poc_parts.append(f"[{i}]\n" + "\n".join(entry_parts))
        g["_poc_combined"] = "\n".join(poc_parts) if poc_parts else "N/A"

        # Count for summary
        g["_occurrence_count"] = len(g["_poc_flows"])

        result.append(g)

    return result



def detect_tech_stack(cx_rows: list[dict]) -> list[dict]:
    """
    Infer tech stack entries from QueryPath language prefixes and source
    file extensions.  Returns a list of dicts with keys:
        srno, tech_stack, open_port, services
    """
    import os as _os

    # Language from QueryPath prefix  (e.g. "CSharp\\Cx\\..." → C#)
    LANG_MAP = {
        "csharp":     "C# / .NET",
        "javascript": "JavaScript",
        "java":       "Java",
        "python":     "Python",
        "php":        "PHP",
        "go":         "Go",
        "kotlin":     "Kotlin",
        "swift":      "Swift",
        "typescript": "TypeScript",
        "vbscript":   "VBScript",
        "plsql":      "PL/SQL",
        "apex":       "Apex (Salesforce)",
        "ruby":       "Ruby",
        "scala":      "Scala",
    }

    # Extension → framework/tech hint
    EXT_MAP = {
        ".cshtml": "ASP.NET MVC (Razor Views)",
        ".aspx":   "ASP.NET Web Forms",
        ".ashx":   "ASP.NET HTTP Handlers",
        ".cs":     "C# / ASP.NET",
        ".vb":     "VB.NET",
        ".js":     "JavaScript",
        ".ts":     "TypeScript",
        ".jsx":    "React (JSX)",
        ".tsx":    "React (TSX)",
        ".vue":    "Vue.js",
        ".py":     "Python",
        ".java":   "Java",
        ".kt":     "Kotlin",
        ".php":    "PHP",
        ".rb":     "Ruby",
        ".go":     "Go",
        ".swift":  "Swift",
        ".rs":     "Rust",
        ".cpp":    "C++",
        ".c":      "C",
        ".scala":  "Scala",
        ".sql":    "SQL",
        ".xml":    "XML / Config",
        ".json":   "JSON / Config",
        ".yaml":   "YAML / Config",
        ".yml":    "YAML / Config",
        ".tf":     "Terraform (IaC)",
    }

    langs_found = set()
    frameworks_found = set()

    for row in cx_rows:
        qp = str(row.get("QueryPath") or "")
        # First segment of QueryPath is the language
        first_seg = qp.split("\\")[0].lower()
        if first_seg in LANG_MAP:
            langs_found.add(LANG_MAP[first_seg])

        for path_col in ("SrcFileName", "DestFileName"):
            fp = str(row.get(path_col) or "")
            if fp:
                ext = _os.path.splitext(fp)[1].lower()
                if ext in EXT_MAP:
                    frameworks_found.add(EXT_MAP[ext])

    # Merge: remove duplicates already captured by lang (e.g. "C# / ASP.NET" ⊇ "C# / .NET")
    all_tech = set(langs_found) | set(frameworks_found)

    # Collapse obvious redundancies
    if "ASP.NET MVC (Razor Views)" in all_tech:
        all_tech.discard("C# / .NET")    # already implied
        all_tech.discard("C# / ASP.NET")
        all_tech.add("C# / ASP.NET MVC")
    elif "C# / ASP.NET" in all_tech:
        all_tech.discard("C# / .NET")

    tech_str = ", ".join(sorted(all_tech))

    return [{
        "srno":       1,
        "tech_stack": tech_str or "N/A",
        "open_port":  "N/A",
        "services":   "N/A",
    }]


# ---------------------------------------------------------------------------
# Fill the Tech Stack sheet
# ---------------------------------------------------------------------------

def write_tech_stack(ws_tech, tech_entries: list[dict]):
    """
    Populate the 'Tech Stack' sheet.
    Template layout:
      Row 6  → header  (Sr.no | Tech Stack | [C3-C4 empty] | Open Port | Services)
      Row 7+ → data
    """
    # Find the header row (contains 'Sr.no' or 'Sr. No')
    header_row = None
    for r in range(1, ws_tech.max_row + 3):
        for c in range(1, ws_tech.max_column + 1):
            val = str(ws_tech.cell(row=r, column=c).value or "").lower().replace(" ", "")
            if "srno" in val:
                header_row = r
                break
        if header_row:
            break
    if not header_row:
        header_row = 6

    data_start = header_row + 1

    # Capture header-row style for reuse
    HEADER_FILL_TS = PatternFill("solid", fgColor="808080")
    HEADER_FONT_TS = Font(bold=True, size=10)
    HEADER_ALIGN_TS = Alignment(horizontal="left", vertical="center", wrap_text=True)

    DATA_FONT_TS  = Font(size=10)
    DATA_ALIGN_TS = Alignment(horizontal="left", vertical="center", wrap_text=True)

    # Delete any existing data rows below the header
    for r in range(ws_tech.max_row, data_start - 1, -1):
        ws_tech.delete_rows(r)

    # Column positions matching the template:
    #   C1 = Sr.no, C2 = Tech Stack, C5 = Open Port, C6 = Services
    COL_SRNO   = 1
    COL_TECH   = 2
    COL_PORT   = 5
    COL_SVC    = 6

    for idx, entry in enumerate(tech_entries, start=1):
        r = data_start + idx - 1

        data_map = {
            COL_SRNO: idx,
            COL_TECH: entry["tech_stack"],
            COL_PORT: entry["open_port"],
            COL_SVC:  entry["services"],
        }

        for c, value in data_map.items():
            cell = ws_tech.cell(row=r, column=c, value=value)
            cell.font      = DATA_FONT_TS
            cell.alignment = DATA_ALIGN_TS
            cell.border    = THIN_BORDER

        # Rough row height
        lines = str(entry["tech_stack"]).count(",") // 3 + 2
        ws_tech.row_dimensions[r].height = max(30, lines * 15)

    print(f"[✓] Tech Stack sheet updated with {len(tech_entries)} entr{'y' if len(tech_entries)==1 else 'ies'}.")


# ---------------------------------------------------------------------------
# Read the Checkmarx report  (auto-detects .csv or .xlsx)
# ---------------------------------------------------------------------------

def _sniff_csv(path: str):
    """
    Detect CSV delimiter and encoding.
    Tries UTF-8-BOM first (common Checkmarx export), falls back to latin-1.
    Returns (encoding, delimiter).
    """
    import csv as _csv

    for enc in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            with open(path, "r", encoding=enc, newline="") as f:
                sample = f.read(4096)
            dialect = _csv.Sniffer().sniff(sample, delimiters=",;\t")
            return enc, dialect.delimiter
        except Exception:
            continue
    # Fallback: UTF-8 + comma
    return "utf-8-sig", ","


def _read_csv(path: str) -> list[dict]:
    """Parse a Checkmarx CSV export into a list of friendly-key dicts."""
    import csv as _csv

    encoding, delimiter = _sniff_csv(path)
    print(f"[→] CSV detected  — encoding={encoding}, delimiter={repr(delimiter)}")

    rows = []
    with open(path, "r", encoding=encoding, newline="") as f:
        reader = _csv.DictReader(f, delimiter=delimiter)

        # Normalise the CSV headers (strip whitespace / BOM remnants)
        raw_headers = reader.fieldnames or []
        norm_headers = {h.strip(): h for h in raw_headers}

        # Build a lookup:  friendly_name → actual CSV column name
        col_map = {}
        missing = []
        for friendly, csv_header in CX_HEADERS.items():
            # Try exact match first, then case-insensitive
            if csv_header in norm_headers:
                col_map[friendly] = norm_headers[csv_header]
            else:
                ci = {k.lower(): v for k, v in norm_headers.items()}
                if csv_header.lower() in ci:
                    col_map[friendly] = ci[csv_header.lower()]
                else:
                    missing.append(csv_header)

        if missing:
            print(f"[!] Warning: {len(missing)} expected column(s) not found in CSV:")
            for m in missing:
                print(f"      - {m}")
            print("    Available columns:", list(norm_headers.keys()))

        for csv_row in reader:
            row_data = {}
            for friendly, actual_col in col_map.items():
                row_data[friendly] = csv_row.get(actual_col, None) or None
            # Skip completely empty rows
            if all(v is None for v in row_data.values()):
                continue
            rows.append(row_data)

    return rows


def _read_xlsx(path: str) -> list[dict]:
    """Parse a Checkmarx XLSX export into a list of friendly-key dicts."""
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb.active

    rows = []
    for row_idx in range(2, ws.max_row + 1):
        row_data = {}
        for friendly_name, col_idx in CX.items():
            cell_val = ws.cell(row=row_idx, column=col_idx).value
            row_data[friendly_name] = cell_val
        # Skip completely empty rows
        if all(v is None for v in row_data.values()):
            continue
        rows.append(row_data)

    return rows


def read_checkmarx(path: str) -> list[dict]:
    """Auto-detect .csv or .xlsx and return list of normalised row dicts."""
    ext = os.path.splitext(path)[1].lower()

    if ext == ".csv":
        rows = _read_csv(path)
    elif ext in (".xlsx", ".xls"):
        rows = _read_xlsx(path)
    else:
        # Try to sniff — if it looks like CSV text, parse as CSV
        try:
            rows = _read_csv(path)
            print(f"[!] Unknown extension '{ext}' — parsed as CSV.")
        except Exception:
            rows = _read_xlsx(path)
            print(f"[!] Unknown extension '{ext}' — parsed as XLSX.")

    # Filter rows where Query is None/empty (can happen with CSV trailing lines)
    rows = [r for r in rows if r.get("Query")]

    print(f"[✓] Read {len(rows)} vulnerabilities from Checkmarx report.")
    return rows

# ---------------------------------------------------------------------------
# Copy the template workbook and fill the Vulnerability Details sheet
# ---------------------------------------------------------------------------

def write_output(template_path: str, cx_rows: list[dict], output_path: str):
    wb = openpyxl.load_workbook(template_path)

    # ── Group duplicate vulnerabilities ──────────────────────────────────
    original_count = len(cx_rows)
    cx_rows = group_vulnerabilities(cx_rows)
    print(f"[✓] Grouped {original_count} rows → {len(cx_rows)} unique vulnerabilities.")

    # ── Vulnerability Details sheet ─────────────────────────────────────
    ws = wb["Vulnerability Details"]

    # Find the first real header row (contains "Sr. No")
    header_row = None
    for r in range(1, 10):
        for c in range(1, ws.max_column + 1):
            if ws.cell(row=r, column=c).value == "Sr. No":
                header_row = r
                break
        if header_row:
            break

    if not header_row:
        print("[WARN] Could not find header row – defaulting to row 3.")
        header_row = 3

    data_start = header_row + 1

    # Clear existing sample data rows (keep template formatting intact on row 4
    # by using it as a style source, then overwrite).
    # We'll copy style from the first data row in the template.
    style_row = data_start  # row 4 in the template

    def get_cell_styles(ws, row):
        """Return a list of style dicts for each column in the row."""
        styles = {}
        for c in range(1, ws.max_column + 1):
            cell = ws.cell(row=row, column=c)
            styles[c] = {
                "font":      copy.copy(cell.font),
                "alignment": copy.copy(cell.alignment),
                "border":    copy.copy(cell.border),
            }
        return styles

    template_styles = get_cell_styles(ws, style_row)

    # Delete all existing data rows (keep only header rows)
    max_existing = ws.max_row
    for r in range(max_existing, data_start - 1, -1):
        ws.delete_rows(r)

    # ── Write data rows ──────────────────────────────────────────────────
    NUM_COLS = 19  # columns A..S

    for idx, row_data in enumerate(cx_rows, start=1):
        r = data_start + idx - 1

        severity   = str(row_data.get("ResultSeverity") or "").strip()
        status     = str(row_data.get("ResultStatus") or "").strip()
        query      = str(row_data.get("Query") or "").strip()
        owasp      = pick_owasp(row_data)
        # Use pre-combined POC if grouping was done, else build single-flow POC
        poc        = row_data.get("_poc_combined") or build_poc(row_data)
        link       = str(row_data.get("Link") or "").strip()
        src_file   = str(row_data.get("SrcFileName") or "").strip()
        comment    = str(row_data.get("Comment") or "").strip()
        state      = str(row_data.get("ResultState") or "").strip()
        query_path = str(row_data.get("QueryPath") or "").strip()
        occurrence = row_data.get("_occurrence_count", "")

        # External security references for this vulnerability type
        sec_refs   = lookup_references(query)
        remediation = lookup_remediation(query)

        # Map columns
        cell_values = {
            1:  idx,          # Sr. No
            2:  query,        # Vulnerability Title
            3:  severity,     # Risk Level
            4:  status,       # Status
            5:  "",           # CVSS Score  (not available in SAST)
            6:  "",           # DREAD Score (not available in SAST)
            7:  owasp,        # OWASP / CWE Category
            8:  f"{query_path}" + (f" ({occurrence} occurrences)" if occurrence else ""),  # Abstract
            # POC: file-level flows + Checkmarx deep-link for reviewer navigation
            9:  poc + (f"\n\nCheckmarx Link:\n{link}" if link else ""),
            10: "",           # Replication Effort
            11: "",           # Impact
            # Vulnerable URLs/IPs → blank (filled manually by analyst)
            12: "",
            # Affected Assets → blank (filled manually by analyst)
            13: "",
            14: remediation,  # Remediation recommendation (auto-populated)
            15: "",           # Remediation Effort
            # References → left blank (filled manually by analyst)
            16: "",
            17: "",           # Client Justification
            18: comment if comment.lower() not in ("none", "") else "",  # NetSentries Comments
            19: "",           # Remarks → left blank (filled manually by analyst)
        }

        rfill = risk_fill(severity)

        for c, value in cell_values.items():
            cell = ws.cell(row=r, column=c, value=value)

            # Apply base style from template (if available)
            if c in template_styles:
                cell.font      = copy.copy(template_styles[c]["font"])
                cell.alignment = copy.copy(template_styles[c]["alignment"])
                cell.border    = copy.copy(template_styles[c]["border"])
            else:
                cell.font      = DATA_FONT
                cell.alignment = DATA_ALIGN
                cell.border    = THIN_BORDER

            # Risk-level column gets colour fill
            if c == 3 and severity:
                cell.fill = rfill
                # Use dark font for light backgrounds
                if severity in ("Low", "Info"):
                    cell.font = Font(size=10, bold=True, color="000000")
                else:
                    cell.font = Font(size=10, bold=True, color="FFFFFF")

        # Auto-height: rough estimate – 15pt per line, min 30
        lines = max(
            str(v).count("\n") + 1
            for v in cell_values.values() if v
        ) if any(cell_values.values()) else 1
        ws.row_dimensions[r].height = max(30, lines * 15)

    # ── Preserve column widths from template ─────────────────────────────
    # (already preserved because we loaded the template)

    # ── Tech Stack sheet ─────────────────────────────────────────────────
    if "Tech Stack" in wb.sheetnames:
        ws_tech = wb["Tech Stack"]
        tech_entries = detect_tech_stack(cx_rows)
        write_tech_stack(ws_tech, tech_entries)
    else:
        print("[WARN] 'Tech Stack' sheet not found in template – skipping.")

    # ── Save ────────────────────────────────────────────────────────────
    wb.save(output_path)
    print(f"[✓] Output saved → {output_path}")

# ---------------------------------------------------------------------------
# Summary statistics
# ---------------------------------------------------------------------------

def print_summary(cx_rows: list[dict]):
    from collections import Counter

    # cx_rows at this point are the RAW ungrouped rows (passed from main)
    # We re-group here just to get occurrence counts for the summary
    grouped = group_vulnerabilities(cx_rows)

    sev_count  = Counter()
    stat_count = Counter()
    for r in cx_rows:
        sev  = str(r.get("ResultSeverity") or "Unknown").strip()
        stat = str(r.get("ResultStatus") or "Unknown").strip()
        sev_count[sev]  += 1
        stat_count[stat] += 1

    print("\n" + "=" * 60)
    print("  CHECKMARX → EXAMPLE FORMAT  |  CONVERSION SUMMARY")
    print("=" * 60)
    print(f"  Raw rows in Checkmarx file    : {len(cx_rows)}")
    print(f"  Unique vulnerabilities (rows) : {len(grouped)}")
    print(f"  Compression ratio             : {len(cx_rows)}:{len(grouped)}")

    print("\n  Grouped Vulnerabilities (occurrences each):")
    for g in grouped:
        cnt = g.get("_occurrence_count", 1)
        sev = g.get("ResultSeverity", "?")
        name = g.get("Query", "?")
        print(f"    [{sev:<8}]  {cnt:>3}x  {name}")

    print("\n  By Severity (raw rows):")
    for sev in ["Critical", "High", "Medium", "Low", "Info"]:
        if sev in sev_count:
            bar = "█" * sev_count[sev]
            print(f"    {sev:<10} {sev_count[sev]:>3}  {bar}")

    print("\n  By Status:")
    for stat, cnt in stat_count.most_common():
        bar = "█" * cnt
        print(f"    {stat:<15} {cnt:>3}  {bar}")

    print("=" * 60)

# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Batch conversion helper
# ---------------------------------------------------------------------------

SUPPORTED_EXTS = (".csv", ".xlsx", ".xls")


def convert_single(input_path, template_path, output_path):
    """Convert one file and return the raw cx_rows (for summary)."""
    cx_rows = read_checkmarx(input_path)
    write_output(template_path, cx_rows, output_path)
    return cx_rows


def run_batch(input_dir, template_path, output_dir):
    """Process every CSV/XLSX in input_dir and write results to output_dir."""
    import glob

    os.makedirs(output_dir, exist_ok=True)

    # Collect all supported input files
    input_files = []
    for ext in SUPPORTED_EXTS:
        input_files.extend(sorted(glob.glob(os.path.join(input_dir, f"*{ext}"))))

    # Deduplicate (glob may overlap on case-insensitive filesystems)
    seen, unique_files = set(), []
    for f in input_files:
        key = os.path.normcase(os.path.abspath(f))
        if key not in seen:
            seen.add(key)
            unique_files.append(f)

    if not unique_files:
        sys.exit(
            f"[ERROR] No CSV or XLSX files found in: {input_dir}\n"
            f"        Supported extensions: {', '.join(SUPPORTED_EXTS)}"
        )

    print(f"\n[→] Batch mode  |  {len(unique_files)} file(s) found in: {input_dir}")
    print(f"[→] Output dir  : {output_dir}")
    print(f"[→] Template    : {template_path}")
    print("=" * 60)

    success_count, fail_count = 0, 0

    for idx, input_path in enumerate(unique_files, 1):
        base_name   = os.path.splitext(os.path.basename(input_path))[0]
        output_path = os.path.join(output_dir, f"{base_name}.xlsx")

        print(f"\n[{idx}/{len(unique_files)}] {os.path.basename(input_path)}")
        print(f"         → {output_path}")

        try:
            convert_single(input_path, template_path, output_path)
            print(f"  [✓] Done")
            success_count += 1
        except Exception as e:
            print(f"  [✗] FAILED: {e}")
            fail_count += 1

    print("\n" + "=" * 60)
    print("  BATCH CONVERSION COMPLETE")
    print("=" * 60)
    print(f"  Files processed : {len(unique_files)}")
    print(f"  Succeeded       : {success_count}")
    if fail_count:
        print(f"  Failed          : {fail_count}")
    print(f"  Output folder   : {os.path.abspath(output_dir)}")
    print("=" * 60)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Convert Checkmarx SAST report(s) (.csv or .xlsx) to NetSentries example format.",
        formatter_class=argparse.RawTextHelpFormatter
    )

    # ── Single-file args ──────────────────────────────────────────────────
    single = parser.add_argument_group("Single-file mode")
    single.add_argument(
        "--input", "-i", default=None, metavar="FILE",
        help="Checkmarx report file (.csv or .xlsx).\n"
             "Auto-detected if omitted (looks for checkmarx.csv / checkmarx.xlsx)."
    )
    single.add_argument(
        "--output", "-o", default="output_report.xlsx", metavar="FILE",
        help="Output .xlsx file path  (default: output_report.xlsx)"
    )

    # ── Batch args ────────────────────────────────────────────────────────
    batch = parser.add_argument_group("Batch mode  (processes a whole folder)")
    batch.add_argument(
        "--input-dir", "-I", default=None, metavar="DIR",
        help="Folder containing Checkmarx report files.\n"
             "All .csv / .xlsx files in the folder are converted."
    )
    batch.add_argument(
        "--output-dir", "-O", default=None, metavar="DIR",
        help="Folder where output .xlsx files are saved.\n"
             "Each output file keeps the same base name as its input."
    )

    # ── Shared ────────────────────────────────────────────────────────────
    parser.add_argument(
        "--template", "-t", default="example file.xlsx", metavar="FILE",
        help="NetSentries template file  (default: 'example file.xlsx')"
    )

    args = parser.parse_args()

    # Validate template (needed by both modes)
    if not os.path.isfile(args.template):
        sys.exit(f"[ERROR] Template file not found: {args.template}")

    # ── Batch mode ────────────────────────────────────────────────────────
    if args.input_dir is not None or args.output_dir is not None:
        if not args.input_dir:
            sys.exit("[ERROR] --input-dir is required in batch mode.")
        if not args.output_dir:
            sys.exit("[ERROR] --output-dir is required in batch mode.")
        if not os.path.isdir(args.input_dir):
            sys.exit(f"[ERROR] Input folder not found: {args.input_dir}")
        run_batch(args.input_dir, args.template, args.output_dir)
        return

    # ── Single-file mode ──────────────────────────────────────────────────
    if args.input is None:
        for candidate in ("checkmarx.csv", "checkmarx.xlsx", "checkmarx.xls"):
            if os.path.isfile(candidate):
                args.input = candidate
                print(f"[→] Auto-detected input file : {candidate}")
                break
        if args.input is None:
            sys.exit(
                "[ERROR] No input file found.\n"
                "        Options:\n"
                "          1. Place checkmarx.csv or checkmarx.xlsx in the current folder\n"
                "          2. Use --input <file>\n"
                "          3. Use --input-dir <folder> --output-dir <folder>  (batch mode)"
            )

    if not os.path.isfile(args.input):
        sys.exit(f"[ERROR] Input file not found: {args.input}")

    print(f"[→] Reading Checkmarx report : {args.input}")
    print(f"[→] Using template           : {args.template}")
    print(f"[→] Output will be written   : {args.output}")
    print()

    cx_rows = convert_single(args.input, args.template, args.output)
    print_summary(cx_rows)
    print(f"\n[✓] Done! Open '{args.output}' to review the converted report.")


if __name__ == "__main__":
    main()

