# Checkmarx → NetSentries Report Converter

Convert a **Checkmarx SAST report** (`checkmarx.xlsx`) into the
**NetSentries example report format** (`example file.xlsx`) — fully offline.

---

## 📦 Package Contents

```
checkmarx_converter/
├── install.sh                  ← Run this first (offline installer)
├── checkmarx_to_example.py     ← The conversion script
├── example file.xlsx           ← NetSentries report template
├── checkmarx.xlsx              ← Your Checkmarx SAST report (replace with yours)
├── README.md                   ← This file
└── wheels/
    ├── openpyxl-3.1.5-py2.py3-none-any.whl
    └── et_xmlfile-2.0.0-py3-none-any.whl
```

---

## 🚀 Quick Start (Kali Linux)

### Step 1 — Make installer executable & run it
```bash
chmod +x install.sh
./install.sh
```

### Step 2 — Run the converter
```bash
python3 checkmarx_to_example.py
```

Output file: **`output_report.xlsx`** (created in the same folder)

---

## ⚙️ Advanced Usage

```bash
python3 checkmarx_to_example.py \
  --input  checkmarx.xlsx \
  --template "example file.xlsx" \
  --output  my_report.xlsx
```

| Argument | Default | Description |
|---|---|---|
| `--input` / `-i` | `checkmarx.xlsx` | Checkmarx SAST export file |
| `--template` / `-t` | `example file.xlsx` | NetSentries template file |
| `--output` / `-o` | `output_report.xlsx` | Output file path |

---

## 📊 What the script does

| Sheet | What gets filled |
|---|---|
| **Vulnerability Details** | All vulnerabilities grouped by type — similar findings are merged into one row with all affected files and POC flows listed |
| **Tech Stack** | Auto-detected from file extensions & QueryPaths in the Checkmarx data |

### Grouping logic
Multiple Checkmarx rows with the same **Query** (e.g. 100× "SQL Injection") are
collapsed into **1 row** containing:
- Highest severity across all instances
- All unique affected source files (numbered)
- All unique Source→Sink POC flows (numbered)
- All unique statuses / result states

### Severity colour coding
| Severity | Cell Colour |
|---|---|
| Critical | 🔴 Dark Red |
| High | 🔴 Red |
| Medium | 🟠 Amber |
| Low | 🟡 Yellow |
| Info | 🟢 Green |

---

## 📋 Requirements

- Python 3.8+ (pre-installed on Kali Linux)
- `openpyxl` 3.1.5 — included in `wheels/`
- `et-xmlfile` 2.0.0 — included in `wheels/`

**No internet connection required.**

---

## 🔧 Manual install (if install.sh fails)

```bash
pip3 install wheels/et_xmlfile-2.0.0-py3-none-any.whl --no-index
pip3 install wheels/openpyxl-3.1.5-py2.py3-none-any.whl --no-index
```

---

## ❓ Troubleshooting

| Problem | Fix |
|---|---|
| `python3: command not found` | `sudo apt-get install python3` |
| `pip3: command not found` | `sudo apt-get install python3-pip` |
| `ModuleNotFoundError: openpyxl` | Re-run `./install.sh` |
| Permission denied on install.sh | `chmod +x install.sh` |
| Template not found | Ensure `example file.xlsx` is in the same folder |
